import { getStore } from "@netlify/blobs";

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json" } });

const FIELDS = ["brand", "drawDate", "drawNo"];

async function load(store) {
  const defaults = {
    viewerPassword: "1234",
    adminPassword: process.env.ADMIN_PASSWORD || "admin123",
    brand: "เลขเด็ดประจำงวด",
    drawDate: "1 พฤศจิกายน 2569",
    drawNo: "1",
  };
  const saved = await store.get("config", { type: "json" });
  return { ...defaults, ...(saved || {}) };
}

export default async (req) => {
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  const store = getStore("lucky");
  const cfg = await load(store);
  let body;
  try { body = await req.json(); } catch { return json({ error: "คำขอไม่ถูกต้อง" }, 400); }
  const path = new URL(req.url).pathname;
  const pub = async () => ({
    ...Object.fromEntries(FIELDS.map((k) => [k, cfg[k]])),
    image: (await store.get("image")) || "",
  });

  if (path.endsWith("/brand")) return json({ brand: cfg.brand });

  if (path.endsWith("/unlock")) {
    if (body.password !== cfg.viewerPassword) return json({ error: "รหัสผ่านไม่ถูกต้อง" }, 401);
    return json(await pub());
  }

  if (path.endsWith("/admin")) {
    if (body.adminPassword !== cfg.adminPassword) return json({ error: "รหัสผ่านแอดมินไม่ถูกต้อง" }, 401);
    if (body.action === "save") {
      for (const k of FIELDS) if (typeof body[k] === "string") cfg[k] = body[k].slice(0, 60);
      if (body.viewerPassword) cfg.viewerPassword = String(body.viewerPassword).slice(0, 100);
      if (body.newAdminPassword) cfg.adminPassword = String(body.newAdminPassword).slice(0, 100);
      if (typeof body.image === "string") {
        if (body.image === "") await store.delete("image");
        else if (/^data:image\/(jpeg|png|webp);base64,/.test(body.image) && body.image.length < 4_000_000)
          await store.set("image", body.image);
      }
      await store.setJSON("config", cfg);
    }
    return json({ ...(await pub()), viewerPassword: cfg.viewerPassword });
  }
  return json({ error: "ไม่พบหน้านี้" }, 404);
};

export const config = { path: "/api/*" };
